// import { commonAlert } from '../util/util';
export default async (url = '', data = {}, type = 'GET', Options) => {
  const timeout = 60000;
  type = type.toUpperCase();


  // if (type == 'GET') {
  //   let dataStr = ''; // 数据拼接字符串
  //   Object.keys(data).forEach((key) => {
  //     dataStr += key + '=' + data[key] + '&';
  //   });

  //   if (dataStr !== '') {
  //     dataStr = dataStr.substr(0, dataStr.lastIndexOf('&'));
  //     url = url + '?' + dataStr;
  //   }
  // }
  return new Promise((resolve) => {
    let requestObj;
    if (window.XMLHttpRequest) {
      requestObj = new window.XMLHttpRequest();
    } else {
      requestObj = new window.ActiveXObject('Msxml2.XMLHTTP');
    }

    let sendData = '';
    requestObj.open(type, url, true);
    if (type == 'POST') {
      if (Options) {
        requestObj.setRequestHeader('Content-type', Options.header);
        sendData = JSON.stringify(data);
      } else {
        Object.keys(data).forEach((key) => {
          sendData += key + '=' + data[key] + '&';
        });
      }
    }

    // requestObj.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    // requestObj.setRequestHeader('Content-type', 'application/json; charset=UTF-8');
    
    // requestObj.withCredentials = true; //支持跨域发送cookies
    requestObj.send(sendData);

    const ptr = setTimeout(() => {
      if (requestObj.readyState !== 4) {
        // commonAlert({ content: '请求超时' });
        requestObj.abort();
      }
    }, timeout);
    requestObj.onreadystatechange = () => {
      if (requestObj.readyState == 4) {
        clearTimeout(ptr);
        let response = requestObj.response;
        if (response && typeof response !== 'object') {
          try {
            response = JSON.parse(response);
          } catch (err) {
            // response = (new Function('return' + response))();
            response = () => response;
            response();
          }
        }
        if (requestObj.status == 200) {
          resolve(response);
          // resolve(response.data || response);
        }
      }
    };
  });
};
