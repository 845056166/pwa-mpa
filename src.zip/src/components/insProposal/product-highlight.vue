<template>
  <!-- 保险产品亮点 -->
  <div class="product-highlight">
    <div class="product-highlight-box">
      <h3 class="product-highlight-title">
        <span class="title-name">产品亮点</span>
      </h3>
      <div class="highlight-example-list">
        <div class="highlight-example-list-item" v-for="(item, index) in insuranceFeeItem" :key="'' + index + item.title"  :class="{'border-bottom': index !== insuranceFeeItem.length - 1}">
          <h4>
            <img v-if="item.icon" :src="oldHighlightItemIconObj[item.icon] || highlightItemIconObj[item.icon]" />
            <div>{{item.title}}</div>
          </h4>
          <p v-html="item.paySum"></p>
          <!-- 安心百分百特殊处理，没有点击弹窗 -->
          <div class="anxin" v-html="item.desc"></div>
        </div>
      </div>
      <div class="product-highlight-notice border-top">
        【说明】以上给付原因及标准仅供了解产品使用，实际以保险条款描述为准。以上保险利益中的给付金额如以万元为单位显示，对应的数值均为四舍五入并保留两位小数所得，与实际数值可能会略有差异。
      </div>
      <div class="highlight-bottom">
        <div class="highlight-bottom-btn highlight-bottom-insuredLiability" @click="jumpTo('all', insuranceFeeItem)">保险责任(完整版)</div>
        <div class="highlight-bottom-btn highlight-bottom-productTerms" @click="open('clauseShow')">产品条款</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'productHighlight',
  props: {
    insuranceFeeItem: {
      type: Array,
      default() {
        return [];
      },
    },
    mainPlanCode: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      highlightItemIconObj: { // 保障种类图标
        'icon-premium': require('../../assets/img/insProposal/icon-保费豁免.png'),
        'icon-insurance': require('../../assets/img/insProposal/icon-保障.png'),
        'icon-malignancyl': require('../../assets/img/insProposal/icon-恶性肿瘤保障.png'),
        'icon-returneeFee': require('../../assets/img/insProposal/icon-归国药品费用.png'),
        'icon-overseasMedical': require('../../assets/img/insProposal/icon-海外医疗.png'),
        'icon-travellingFee': require('../../assets/img/insProposal/icon-交通费用.png'),
        'icon-education': require('../../assets/img/insProposal/icon-教育储备金.png'),
        'icon-earned': require('../../assets/img/insProposal/icon-满期保障.png'),
        'icon-franchise': require('../../assets/img/insProposal/icon-免陪额.png'),
        'icon-survival2': require('../../assets/img/insProposal/icon-年金.png'),
        'icon-escortMoney': require('../../assets/img/insProposal/icon-陪护金.png'),
        'icon-slightInjury': require('../../assets/img/insProposal/icon-轻度受伤.png'),
        'icon-seriousMildSick': require('../../assets/img/insProposal/icon-轻度医疗保障.png'),
        'icon-mildSick': require('../../assets/img/insProposal/icon-轻度重疾保障.png'),
        'icon-specialScikPayForChild': require('../../assets/img/insProposal/icon-少儿特定疾病保障.png'),
        'icon-survival': require('../../assets/img/insProposal/icon-生存保险金.png'),
        'icon-lifeIns': require('../../assets/img/insProposal/icon-生存保险利益.png'),
        'icon-survivalPay': require('../../assets/img/insProposal/icon-生存给付金.png'),
        'icon-specialSick': require('../../assets/img/insProposal/icon-特定重疾.png'),
        // 'icon-未定义': require('../../assets/img/insProposal/icon-未定义.png'),
        'icon-endowment': require('../../assets/img/insProposal/icon-养老金保障.png'),
        'icon-primarycare': require('../../assets/img/insProposal/icon-一般医疗保险金.png'),
        'icon-repatriationFee': require('../../assets/img/insProposal/icon-遗体遣返费用.png'),
        'icon-distance': require('../../assets/img/insProposal/icon-异地就诊.png'),
        'icon-fullDsiable': require('../../assets/img/insProposal/icon-意外全残保障.png'),
        'icon-accDisblity': require('../../assets/img/insProposal/icon-意外伤残保障.png'),
        'icon-mediAcci': require('../../assets/img/insProposal/icon-意外医疗保障.png'),
        'icon-addInsuranceBySport': require('../../assets/img/insProposal/icon-运动涨保障.png'),
        'icon-careInsurance': require('../../assets/img/insProposal/icon-长期陪护护理保险金.png'),
        'icon-death': require('../../assets/img/insProposal/icon-终身身故保障.png'),
        'icon-sick': require('../../assets/img/insProposal/icon-重疾医疗保障.png'),
        'icon-hospital': require('../../assets/img/insProposal/icon-住院保障.png'),
        'icon-hospitalFee': require('../../assets/img/insProposal/icon-住院费用.png'),
        'icon-driveAcc': require('../../assets/img/insProposal/icon-自驾车意外伤害.png'),
      },
      oldHighlightItemIconObj: { // 保障种类图标
        'icon-保费豁免': require('../../assets/img/insProposal/icon-保费豁免.png'),
        'icon-保障': require('../../assets/img/insProposal/icon-保障.png'),
        'icon-恶性肿瘤保障': require('../../assets/img/insProposal/icon-恶性肿瘤保障.png'),
        'icon-归国药品费用': require('../../assets/img/insProposal/icon-归国药品费用.png'),
        'icon-海外医疗': require('../../assets/img/insProposal/icon-海外医疗.png'),
        'icon-交通费用': require('../../assets/img/insProposal/icon-交通费用.png'),
        'icon-教育储备金': require('../../assets/img/insProposal/icon-教育储备金.png'),
        'icon-满期保障': require('../../assets/img/insProposal/icon-满期保障.png'),
        'icon-免陪额': require('../../assets/img/insProposal/icon-免陪额.png'),
        'icon-年金': require('../../assets/img/insProposal/icon-年金.png'),
        'icon-陪护金': require('../../assets/img/insProposal/icon-陪护金.png'),
        'icon-轻度受伤': require('../../assets/img/insProposal/icon-轻度受伤.png'),
        'icon-轻度医疗保障': require('../../assets/img/insProposal/icon-轻度医疗保障.png'),
        'icon-轻度重疾保障': require('../../assets/img/insProposal/icon-轻度重疾保障.png'),
        'icon-少儿特定疾病保障': require('../../assets/img/insProposal/icon-少儿特定疾病保障.png'),
        'icon-生存保险金': require('../../assets/img/insProposal/icon-生存保险金.png'),
        'icon-生存保险利益': require('../../assets/img/insProposal/icon-生存保险利益.png'),
        'icon-生存给付金': require('../../assets/img/insProposal/icon-生存给付金.png'),
        // 'icon-未定义': require('../../assets/img/insProposal/icon-未定义.png'),
        'icon-养老金保障': require('../../assets/img/insProposal/icon-养老金保障.png'),
        'icon-一般医疗保险金': require('../../assets/img/insProposal/icon-一般医疗保险金.png'),
        'icon-遗体遣返费用': require('../../assets/img/insProposal/icon-遗体遣返费用.png'),
        'icon-异地就诊': require('../../assets/img/insProposal/icon-异地就诊.png'),
        'icon-意外全残保障': require('../../assets/img/insProposal/icon-意外全残保障.png'),
        'icon-意外伤残保障': require('../../assets/img/insProposal/icon-意外伤残保障.png'),
        'icon-意外医疗保障': require('../../assets/img/insProposal/icon-意外医疗保障.png'),
        'icon-运动涨保障': require('../../assets/img/insProposal/icon-运动涨保障.png'),
        'icon-长期陪护护理保险金': require('../../assets/img/insProposal/icon-长期陪护护理保险金.png'),
        'icon-终身身故保障': require('../../assets/img/insProposal/icon-终身身故保障.png'),
        'icon-重疾医疗保障': require('../../assets/img/insProposal/icon-重疾医疗保障.png'),
        'icon-住院保障': require('../../assets/img/insProposal/icon-住院保障.png'),
        'icon-住院费用': require('../../assets/img/insProposal/icon-住院费用.png'),
        'icon-自驾车意外伤害': require('../../assets/img/insProposal/icon-自驾车意外伤害.png'),
        'icon-特定重疾': require('../../assets/img/insProposal/icon-特定重疾.png'),
      },
    };
  },
  methods: {
    // 点击产品亮点的文字链接
    proDescLink(params, event) {
      // this.$emit('goDescLink', { params, event });
    },
    // 参数为all，跳转到保险责任完整版，否则跳转到具体详情
    jumpTo(type, insuranceFeeItem, title) {
      if (title) {
        insuranceFeeItem.oneHead = title;
      }
      console.log('nei', type, insuranceFeeItem, title);
      // this.$emit('goDetail', { type, insuranceFeeItem });
    },
    open(flag) {
      console.log(flag);
      // this.$emit('openMask', { flag });
    },
  },
};
</script>

<style lang="scss">
</style>
