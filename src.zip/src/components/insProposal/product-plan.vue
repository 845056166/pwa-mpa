<template>
  <!-- 保险产品计划 -->
  <div class="product-plan">
    <div class="product-plan-box">
      <h3 class="product-plan-title">
        <span class="title-name">产品计划</span>
      </h3>
      <div class="plan-data-box">
        <div class="plan-data" v-if="mainProd.mainPlanShortName" :class="{'plan-medical360': health_360Flag}">
          <div class="plan-data-item fee-during">
            <div class="plan-value">{{mainProd && mainProd.payPeriodDesc || 0}}</div>
            <div class="plan-label">交费期间</div>
          </div>
          <div class="plan-data-item insure-during">
            <div class="plan-value">{{mainProd && mainProd.insurancePeriodDesc || 0}}</div>
            <div class="plan-label">保险期间</div>
          </div>
          <div class="plan-data-item first-fee">
            <template v-if="mainProd && mainProd.payFrequencyType === '2'">
              <div class="plan-value">{{productPlanObj.medical360 && productPlanObj.medical360.totPremIum}}</div>
              <div class="plan-label">每月保费(元)</div>
            </template>
            <template v-else>
              <div class="plan-value">{{health_360Flag ? productPlanObj.medical360.totPremIum360 : productPlanObj.medical360.totPremIum}}</div>
              <div class="plan-label">首年费用合计(元)</div>
            </template>
            <div class="plan-notes" v-if ="health_360Flag">含就医360首年服务费199元</div>
          </div>
          <div class="plan-data-item insure-fee">
            <div class="plan-value">{{mainProductInfo.value}}</div>
            <div class="plan-label">{{mainProductInfo.name}}</div>
          </div>
          <p v-if="mainProd.mainPlanCode === '1060'" class="specialEx">
            <span>* 保障区域：除中国（包括中国大陆及港、澳、台地区）以外的亚洲国家或地区</span>
            <span>* 不同年龄、有无社保、是否首次投保的保费不同，具体保费以费率表为准</span>
          </p>
        </div>
        <div class="plan-product-type" v-show="showMore">
          <table cellspacing="0" cellpadding="0">
            <tr class="plan-tr plan-th">
              <th class="plan-td plan-table-name"><div class="table-div">产品简称</div></th>
              <th class="plan-td plan-table-fee"><div class="table-div">保额/份数</div></th>
              <th class="plan-td plan-table-during"><div class="table-div">交费期/保险期</div></th>
              <th class="plan-td plan-table-first-fee">
                <div class="table-div" v-if="mainProd && mainProd.payFrequencyType === '2'">每月保费</div>
                <div class="table-div" v-else>首年保费</div>
              </th>
            </tr>
            <template v-for="(item, index) in productPlanObj.planInfoList">
              <tr class="plan-tr" :key="`${index}${item.planShortName}`" v-if="item.planCodeForJ">
                  <td class="plan-td plan-table-name"><div class="table-div">{{item.planShortName}}</div></td>
                  <td class="plan-td plan-table-fee"><div class="table-div"></div></td>
                  <td class="plan-td plan-table-during"><div class="table-div"></div></td>
                  <td class="plan-td plan-table-first-fee"><div class="table-div"></div></td>
              </tr>
              <tr class="plan-tr" :key="`${index}${item.planShortName}`" v-else>
                  <td class="plan-td plan-table-name"><div class="table-div">{{item.planShortName}}</div></td>
                  <td class="plan-td plan-table-fee"><div class="table-div">{{setInsuranceFee(item.insuranceFeeDesc)}}</div></td>
                  <td class="plan-td plan-table-during"><div class="table-div">{{item.payPeriodDesc}}/{{item.insurancePeriodDesc}}</div></td>
                  <td class="plan-td plan-table-first-fee">
                    <div class="table-div">¥{{Number(item.premIum) > 1000 ? toThousands(keepTwoDecimal(item.premIum)) : item.premIum}}</div>
                    <div v-if="item.addPremIumDesc && item.addPremIumDesc !== 'null'">{{item.addPremIumDesc}}</div></td>
              </tr>
            </template>
          </table>
          <!-- 百万随我行 -->
          <div v-if="millionInfo && millionInfo.propertyMillionAccompanying === 'Y'">
            <div class="plan-product-type carMillon">
              <div class="plan-esb-list">
                <h3>以下产品由平安产险提供</h3>
                <table cellspacing="0" cellpadding="0">
                  <tr class="plan-tr plan-th">
                    <th class="plan-td plan-table-name"><div class="table-div">产品简称</div></th>
                    <th class="plan-td plan-table-fee"><div class="table-div">保额/份数</div></th>
                    <th class="plan-td plan-table-during"><div class="table-div">交费期/保险期</div></th>
                    <th class="plan-td plan-table-first-fee"><div class="table-div">首年保费</div></th>
                  </tr>
                  <tr class="plan-tr">
                    <td class="plan-td plan-table-name"><div class="table-div">百万随我行</div></td>
                    <td class="plan-td plan-table-fee"><div class="table-div">共享100万</div></td>
                    <td class="plan-td plan-table-during"><div class="table-div">1年/1年</div></td>
                    <td class="plan-td plan-table-first-fee"><div class="table-div">¥{{millionInfo.propertyMillionPremIum}}</div></td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="plan-show-more" @click="isShowMore">{{showMore ? '隐藏更多' : '展示更多'}}<i :class="{'moreHide': showMore}"></i></div>
    </div>
  </div>
</template>
<script>
import numDeal from '@/assets/js/numDeal';

export default {
  mixins: [numDeal],
  name: 'productPlan',
  data() {
    return {
      showMore: false, // 产品计划模块的是否展开
    };
  },
  props: {
    health_360Flag: {
      type: Boolean,
      default: true,
    },
    mainProductInfo: {
      type: Object,
      default() {
        return {};
      },
    },
    mainProd: {
      type: Object,
      default() {
        return {};
      },
    },
    productPlanObj: {
      type: Object,
      default() {
        return {};
      },
    },
    millionInfo: {
      type: Object,
      default: () => {},
    },
  },
  components: {},
  created() {},
  methods: {
    isShowMore() {
      this.showMore = !this.showMore;
      this.$emit('isShowMore');
    },
  },
};
</script>
<style lang="scss" scoped>
@import '@/assets/css/common/mixin.scss';
.plan-show-more {
  &::after {
    @include border(top, #D9D9D9);
  }
  position: relative;
  z-index: 1;
  display: flex;
  height: 50px;
  line-height: 50px;
  justify-content: center;
  align-items: center;
  font-size: 15px;
  color: rgba(0,0,0,0.45);
  i {
    width: 24px;
    height: 11px;
    margin-left: rem(6);
    background-image: url('../../assets/img/insProposal/show-down.png');
    background-repeat: no-repeat;
    background-size: 100% auto;
    &.moreHide {
      background-image: url('../../assets/img/insProposal/hide-up.png');
      background-repeat: no-repeat;
      background-size: 100% auto;
    }
  }
}
.specialEx {
  padding: 0 .3rem;
  text-align: left;
  padding: 0 0.3rem;
  padding-bottom: 18px;
  font-family: PingFangSC-Regular;
  font-size: 13px;
  line-height: 18px;
  color: rgba(0, 0, 0, 0.6);
  span {
    display: block;
  }
}
</style>
