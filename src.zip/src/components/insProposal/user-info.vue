<template>
  <!-- 用户信息 -->
  <div class="user-wrap">
    <h1 class="title">
      <p>敬呈
      <span class="user-name">{{userInfo.appClientName}}</span>
      {{userInfo.appClientSex === 'M' ? '先生' : '女士'}}的</p>
      <span class="prod-name"> {{mainProdName}}</span>
      专属产品方案
    </h1>
    <!-- isSameClient为Y表示投保人被保人是同一个人，为N表示不同人，需要显示两个人信息； -->
    <!-- 投保人appClient -->
    <div class="user-card appClient" v-if="userInfo.isSameClient === 'N'">
      <div class="user-info">
        <div class="user-portrait" :class="[userInfo.appClientSex === 'M' ? 'male' : 'female']"></div>
        <div class="user-text">
          <div class="nameBox" v-if="hasName(userInfo.appClientName)">{{userInfo.appClientName}}</div>
          <div class="labelBox">性别: {{userInfo.appClientSex === 'M' ? '男' : '女'}}</div>
          <div class="labelBox">年龄: {{userInfo.appClientAge}}岁</div>
        </div>
      </div>
      <div class="user-print appClient"></div>
    </div>
    <!-- 被保人insClient -->
    <div class="user-card insClient">
      <div class="user-info">
        <div class="user-portrait" :class="[userInfo.insClientSex === 'M' ? 'male': 'female']"></div>
        <div class="user-text">
          <div class="nameBox" v-if="hasName(userInfo.insClientName)">{{userInfo.insClientName}}</div>
          <div class="labelBox">性别: {{userInfo.insClientSex === 'M' ? '男' : '女'}}</div>
          <div class="labelBox">年龄: {{userInfo.insClientAge}}岁</div>
        </div>
      </div>
      <div class="user-print" :class="[userInfo.isSameClient === 'Y' ? 'same' : 'insClient']"></div>
    </div>
    <!-- isReserve为Y，表示有其他被保人 -->
    <!-- 其他被保人 -->
    <div class="user-card otherClient" v-if="userInfo.isReserve === 'Y'">
      <div class="user-info">
        <div class="user-portrait male" :class="{'female': userInfo.otherInsClientSex === 'F'}"></div>
        <div class="user-text">
          <div class="nameBox" v-if="hasName(userInfo.otherInsClientName)">{{userInfo.otherInsClientName}}</div>
          <div class="labelBox">性别: {{userInfo.otherInsClientSex === 'M' ? '男' : '女'}}</div>
          <div class="labelBox">年龄: {{userInfo.otherInsClientAge}}岁</div>
        </div>
      </div>
      <div class="user-print otherClient"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'userInfo',
  props: {
    userInfo: {
      type: Object,
      default() {
        return {};
      },
    },
    mainProdName: {
      type: String,
      default: '',
    },
  },
  methods: {
    hasName(name) {
      return name && name !== '--';
    },
  },
};
</script>

<style lang="scss" scoped>
  @import '@/assets/css/common/mixin.scss';
  .user {
    &-wrap {
      margin-top: 9px;
      padding: 0 0.36rem;
      background: #fff;
      position: relative;
      .title{
        position: relative;
        line-height: 21px;
        color: rgba(0,0,0,0.85);
        font-size: 15px;
        font-family: PingFangSC-Regular;
        padding: 16px 60px 17px 0;
        @include font_family(PingFangSC-Regular);
        font-weight: normal;
        p {
          display: inline-block;
        }
        &:before{
          @include border(bottom, #eee);
        }
        .user-name {
          font-family: PingFangSC-Semibold;
          @include font_family(PingFangSC-Semibold);
        }
        .prod-name {
          font-family: PingFangSC-Semibold;
          @include font_family(PingFangSC-Semibold);
          color: #de2a2f;
          &.main-prods-name {
            width: 64%;
            display: inline-block
          }
        }
      }
    }
    &-card {
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      height: 110px;
      padding: 0 0.30rem;
      border-radius: 5px;

      &:not(:last-child) {
        margin-bottom: 21px;
      }
      .user-info {
        display: flex;
        flex: 1;
        .user-portrait {
          width: 70px;
          height: 70px;
          margin-right: 0.36rem;
          &.male {
            background-image: url('../../assets/img/insProposal/male.png');
            background-repeat: no-repeat;
            background-size: 100% 100%;
          }
          &.female {
            background-image: url('../../assets/img/insProposal/female.png');
            background-repeat: no-repeat;
            background-size: 100% 100%;
          }
        }
        .user-text {
          line-height: 20px;
          font-size: 14px;
          color: rgba(0,0,0,0.60);
          letter-spacing: 0;
          display: flex;
          flex-direction: column;
          justify-content: center;
          flex: 1;
          .nameBox {
            margin-bottom: 6px;
            line-height: 26.5px;
            font-size: 19px;
            font-family: PingFangSC-Semibold;
            @include font_family(PingFangSC-Semibold);
            color: rgba(0,0,0,0.85);
          }
          .labelBox:not(:last-child) {
            margin-bottom: 1px;
          }
        }
      }
      .user-print {
        width: 78px;
        height: 78px;
        &.same {
          background-image: url('../../assets/img/insProposal/01.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;
        }
        &.insClient {
          background-image: url('../../assets/img/insProposal/03.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;
        }
        &.otherClient {
          background-image: url('../../assets/img/insProposal/other.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;
        }
        &.appClient {
          background-image: url('../../assets/img/insProposal/02.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;
        }
      }
    }
  }
</style>
