<template>
  <!-- 其他权益 -->
  <div class="product-benefit product-rights" v-if="mainPlanCode === '1372'">
    <div class="product-benefit-box">
      <h3 class="product-benefit-title">
        <span class="title-name">其他权益</span>
      </h3>
      <div class="product-rights-content">
        <p v-for="(item, index) in rightsArr" :key="`rights${index}`"><span v-for="(subItem, index) in item" :key="`rightsSubItem${index}`" @click="open('rightsShow', subItem)">{{subItem.eauityVueKey}}</span></p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'productRights',
  data() {
    return {
      rightsArr: [],
      /* eslint-disable */
      eauityPaymentDescList: [
        {
          eauityVueKey: '血糖管理服务',
          eauityDesc: '在主险合同保险期间内，自主险合同生效之日起，我们向被保险人提供为期3年的血糖管理服务。包括主险合同列…关怀和主动干预、用药指导、线上问诊服务。帮助被保险人提升健康状况、防止或延缓糖尿病严重并发症发生。',
          eauityKeyId: 'bloodGlucose',
          eauityKey: '<span class="blueLink" id="#bloodGlucoseDiv">血糖管理服务</span>',
        },
        {
          eauityVueKey: '加费减免',
          eauityDesc: '承保后的前2个保单年度，我们会根据每个保单年度末的糖化血红蛋白（HbA1c）复查结果，以投保时的加费额为基准，调减您下个保单年度血糖异常风险相关的加费额。<table  width="100%" border="1px" cellspacing="0"><tr><th>投保时HbA1c（%）</th><th>管理后HbA1c（%）</th><th>加费调减比例</th></tr><tr style="text-align: center;"><td rowspan="3">7及以下</td><td>6.0及以下</td><td>100%</td></tr><tr style="text-align: center;"><td>6.1-6.5</td><td>不低于80%</td></tr><tr style="text-align: center;"><td>6.6 - 7</td><td>不低于60%</td></tr><tr style="text-align: center;"><td rowspan="4">7以上</td><td>7及以下</td><td>不低于40%</td></tr><tr style="text-align: center;"><td>7.1 – 7.5</td><td>不低于30%</td></tr><tr style="text-align: center;"><td>7.6 - 8</td><td>不低于20%</td></tr><tr style="text-align: center;"><td>8.1 以上</td><td>0%</td></tr></table><br/>根据第3个保单年度末的糖化血红蛋白（HbA1c）复查结果，并参考前2个保单年度的加费额调减结果，确定第4个保单年度及以后的加费额。',
          eauityKeyId: 'addFee',
          eauityKey: '<span class="blueLink" id="#addFeeDiv">加费减免</span>',
        },
        {
          eauityVueKey: '保单贷款',
          eauityDesc: '投保人可申请相应产品现金价值扣除各项欠款后余额的80%的贷款，每次贷款期限可达6个月，贷款利率由本公司确定。',
          eauityKeyId: '#guaranteeSubDiv',
          eauityKey: '<span class="blueLink" id="guaranteeSub">保单贷款</span>',
        },
        {
          eauityVueKey: '自动垫交',
          eauityDesc: '宽限期结束时投保人仍未支付保险费的，可以用相应现金价值扣除各项欠款后的余额自动垫交到期应交的保险费，合同继续有效。垫交的保费按保单贷款利率计息。',
          eauityKeyId: '#automationAdvanceDiv',
          eauityKey: '<span class="blueLink" id="automationAdvance">自动垫交</span>',
        },
        {
          eauityVueKey: '减额交清',
          eauityDesc: '若投保人决定不再支付保险费，可以申请办理减额交清，减少基本保险金额。无需再支付保险费，合同继续有效（条款另有约定的除外）。',
          eauityKeyId: '#derateClearDiv',
          eauityKey: '<span class="blueLink" id="derateClear">减额交清</span>',
        },
      ],
    };
  },
  props: {
    mainPlanCode: {
      type: String,
      default: '',
    },
    // eauityPaymentDescList: {
    //   type: Array,
    //   default() {
    //     return [];
    //   },
    // },
  },
  created() {
    this.getOtherRights();
  },
  methods: {
    getOtherRights() {
      const objArray = this.eauityPaymentDescList;
      const nObj = {
        0: 2,
        1: 5,
      };
      const res = [];
      for (let i = 0; i < 2; i++) {
        const temp = objArray.slice(i * 2, nObj[i]);
        res.push(JSON.parse(JSON.stringify(temp)));
      }
      console.log(res);
      this.rightsArr = res;
    },
    open(flag, item) {
      // this.$emit('openMask', { flag, item });
    },
  }
};
</script>

