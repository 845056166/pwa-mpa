<template>
  <!-- 保单利益 -->
  <div class="product-benefit">
    <div class="product-benefit-box">
      <h3 class="product-benefit-title">
        <span class="title-name">保单利益</span>
      </h3>
      <div class="benefit-insurance-payment-list">
        <template v-if="benefitInfo.mainProd.mainPlanCode === '1060'">
          <div class="benefit-insurance-payment-list-item border-bottom" v-for="(item) in specialTableBarFor1060" :key="item.E_Name">
            <span class="label">{{item.C_Name}}</span>
            <span class="value">{{renderBenefit(item.E_Name)}}</span>
          </div>
        </template>
        <template v-if="benefitInfo.disableCheckedSingle && benefitInfo.disableCheckedSingle.length > 3">
          <div class="benefit-insurance-payment-list-item border-bottom" v-for="(item, index) in benefitInfo.disableCheckedSingle3" :key="`${item.E_Name}${index}`">
            <span class="label">{{item.C_Name}}</span>
            <span class="value">{{benefitInfo['benResultList'][rangeValue-rangeMin] ? toThousands(benefitInfo['benResultList'][rangeValue-rangeMin][item.E_Name]) : toThousands(benefitInfo['benResultList'][ageMax - rangeMin][item.E_Name])}}</span>
          </div>
        </template>
        <template v-if="benefitInfo.disableCheckedLevels && benefitInfo.disableCheckedLevels.length > 0">
          <div class="benefit-insurance-payment-list-btn">
            <div
              class="benefit-btn"
              v-for="(btn_item, index) in choosedLevelArr"
              :key="`${btn_item.value}${index}`"
              @click="choseOneLevel(index, btn_item)"
              :class="{choosed: levelIndex === index}">
              {{btn_item.name}}
            </div>
          </div>
          <p class="benefit-btn-content">{{levelContent}}</p>
          <div class="benefit-insurance-payment-list-item" v-for="(item, index) in benefitInfo.disableCheckedLevels" :key="`${item.E_Name}${index}`">
            <span class="label">{{item.C_Name}}</span>
            <span class="value">{{benefitInfo['benResultList'][rangeValue-rangeMin] ? toThousands(benefitInfo['benResultList'][rangeValue-rangeMin][`${item.E_Name}${choosedLevel}`]) : toThousands(benefitInfo['benResultList'][ageMax - rangeMin][`${item.E_Name}${choosedLevel}`])}}</span>
          </div>
        </template>
      </div>
      <div class="benefit-insurance-expenditure">
        <p>移动调整年龄可测算每天保费支出</p>
        <div class="range-wrap">
          <div class="range-reduce"></div>
          <div class="range-box" v-if="benefitInfo['benResultList'] && benefitInfo['benResultList'].length > 0">
            <range :min="rangeMin" :max="rangeMax" v-model="rangeValue" :range-bar-height="4"></range>
          </div>
          <div class="range-add"></div>
        </div>
        <p v-if="benefitInfo.mainProd.mainPlanCode !== '1060'">
          <span v-if="rangeValue > ageMax">已过交费期，保障与关爱延续！</span>
          <span v-else>
            交费期内，每天保费支出仅需
            <i>
              {{Math.round(benefitInfo['benResultList'][rangeValue-rangeMin]['ACC_INS_FEE']/benefitInfo['benResultList'][rangeValue-rangeMin]['POL_YEAR']/365)}}<span>元</span>
            </i>
          </span>
        </p>
      </div>
      <!-- <div class="benefit-insurance-schedule"><span @click="open('benefitShow')">查看利益演示表</span></div> -->
    </div>
  </div>
</template>
<script>
import numDeal from '@/assets/js/numDeal';
import range from './range/index';
// import addTapEvent from '@/util/tap.js';

export default {
  mixins: [numDeal],
  name: 'productBenefit',
  props: {
    benefitInfo: {
      type: Object,
      default: () => {},
    },
  },
  components: {
    range,
  },
  data() {
    return {
      column1060: [ // 海外医疗亚洲
        {
          field: 'AGE',
          title: '年龄',
          width: (window.innerWidth) / 3,
        },
        {
          field: 'RENEWAL_PREM',
          title: '保险期间届满60日内重新投保',
          width: (window.innerWidth) / 3,
        },
        {
          field: 'ANNUAL_PREM',
          title: '首次投保或保险期间届满60日后重新投保',
          width: (window.innerWidth) / 3,
        },
      ],
      specialTableBarFor1060: [ // 海外医疗亚洲
        {
          C_Name: '首次投保或保险期间届满60日后重新投保',
          D03: 'N',
          E_Name: 'ANNUAL_PREM',
        },
        {
          C_Name: '保险期间届满60日内重新投保',
          D03: 'N',
          E_Name: 'RENEWAL_PREM',
        },
      ],
      specialFor1060: [],
      rangeValue: 105, // 保单利益块的滑块值
      rangeMin: 1, // 保单利益块的滑块最小值
      rangeMax: 105, // 保单利益块的滑块最大值
      ageMax: 105, // 保单年龄
      choosedLevelArr: [
        {
          name: '低',
          value: '_L',
        },
        {
          name: '中',
          value: '_M',
        },
        {
          name: '高',
          value: '_H',
        },
      ],
      choosedLevel: '_M', // 等级：高（_H),中(_M),低(_L)
      levelIndex: 1,
      levelContent: '“低中高”代表分红水平', // 默认内容
    };
  },
  created() {
    const { mainPlanCode } = this.benefitInfo.mainProd;
    console.log(mainPlanCode, this.benefitInfo, 'created');
    // 判断是否是1060险种
    if (mainPlanCode === '1060') this.getSpecial1060();
    // range插件设置
    this.initRange();
  },
  mounted() {
    this.$nextTick(() => {
      const rangeAdd = document.querySelector('.range-add');
      const rangeReduce = document.querySelector('.range-reduce');
      // addTapEvent(rangeAdd, this.changeRange, 1);
      // addTapEvent(rangeReduce, this.changeRange, -1);
    });
  },
  methods: {
    // 如果是1060险种就需要导入保单利益的配置文件
    getSpecial1060() {
      import('./json/specialFor1060.js').then((modules) => {
        const {
          benResultListFor1060Y,
          benResultListFor1060N,
        } = modules;
        if (this.benefitInfo.insIsMedicalInsured === 'Y') {
          this.specialFor1060 = benResultListFor1060Y;
        } else {
          this.specialFor1060 = benResultListFor1060N;
        }
        console.log('加载完成了');
      });
    },
    renderBenefit(flag) {
      if (!this.specialFor1060.length) {
        return '';
      }
      return this.specialFor1060[this.rangeValue][flag];
    },
    // range插件设置
    initRange() {
      this.rangeMin = (parseInt(this.benefitInfo.insClientAge, 10) + 1) || 1;
      this.rangeMax = (parseInt(this.benefitInfo.insClientAge, 10) + parseInt(this.benefitInfo.maxPolYear, 10)) || 105;
      this.rangeValue = this.rangeMin;
      this.ageMax = parseInt(this.rangeValue, 10) + parseInt(this.benefitInfo.mainProdPayperiod, 10) - 1;
    },
    // 选择高中低档
    choseOneLevel(index, item) {
      console.log(index);
      this.levelIndex = index;
      this.choosedLevel = item.value;
      console.log(this.choosedLevel);
    },
    // 获取高中低等级的内容
    getLevelContent() {
      const {
        mainProd,
        addPlanCodeList,
        lowRate,
        middleRate,
        highRate,
      } = this.benefitInfo;
      // 假设投资回报率
      const investArr = ['996', '938', '1126', '1128', '837', '838', '1128d'];
      // 万能结算水平
      const settleArr = ['866D', '867D'];
      // 分红
      const bonusArr = ['848', '860', '866', '867', '868'];
      if (lowRate || middleRate || highRate) {
        this.levelContent = '“低中高”代表不同假定结算利率';
      }
      if (investArr.includes(mainProd.mainPlanCode)) {
        this.levelContent = '“低中高”代表假设投资回报率';
      }
      if (settleArr.includes(mainProd.mainPlanCode)) {
        this.levelContent = '“低中高”代表万能结算水平';
      }
      // 分红，非分红主险附加小万能（860）
      for (let i = 0, len = addPlanCodeList.length; i < len; i++) {
        if (bonusArr.includes(addPlanCodeList[i]) && mainProd.kind === '02') {
          this.levelContent = '“低中高”代表分红水平&万能结算水平';
        } else if ((!bonusArr.includes(addPlanCodeList[i]) && mainProd.kind !== '02') || ((mainProd.kind === '01' || mainProd.kind === '05') && bonusArr.includes(addPlanCodeList[i]))) {
          this.levelContent = '“低中高”代表万能结算水平';
        }
      }
    },
    // 点击加号或减号改变滑块的值
    changeRange(num) {
      if (this.rangeValue <= this.rangeMin && num < 0) return;
      if (this.rangeValue >= this.rangeMax && num > 0) return;
      this.rangeValue += num;
    },
    open(flag) {
      // this.$emit('openMask', { flag });
    },
  },
};
</script>
