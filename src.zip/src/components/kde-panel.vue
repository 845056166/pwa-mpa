<template>
  <div class="kde-container"
       :style="containerStyle">
    <!-- 头部 header -->
    <nav :style="headerTop">
      <slot name="nav"></slot>
    </nav>
    <!-- 中间区域 content -->
    <section class="main-section"
             :style="contentStyle">
      <slot></slot>
    </section>
    <!-- 底部区域 footer -->
    <footer :id="[showFooter?'footer':'footers']"
            ref="footer"
            :class="{ftBorder}">
      <slot name="footer"></slot>
    </footer>
    <slot name="pop"></slot>
  </div>
</template>

<script>
import { statusBarHeight } from '@/config/index';

export default {
  name: 'panel',
  components: {
    // paHeader
  },
  props: {
    specialFooter: {
      // 底部固定高度不为56px
      type: Boolean,
      default: false,
    },
    showFooter: {
      // 用户计算中间区域高度
      type: Boolean,
      default: true,
    },
    ftBorder: {
      // 用户计算中间区域高度
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      containerStyle: {},
      contentStyle: {},
      headerTop: {},
    };
  },
  created() {
    // this.calContentHeight();
  },
  mounted() {
    this.$nextTick(() => {
      this.calContentHeight();
    });
  },
  methods: {
    // 计算中间区域 样式
    calContentHeight() {
      const headerHeight = 44;
      let footerHeight = 56;
      this.headerTop = {
        height: `${statusBarHeight + 44}`,
      };
      if (this.showFooter) {
        const dom1 = document.querySelector('.slide-left-enter-active #footer');
        const dom2 = document.querySelector('.slide-right-enter-active #footer');
        const dom3 = document.querySelector('#footer');
        if (dom1) footerHeight = dom1.offsetHeight;
        if (dom2) footerHeight = dom2.offsetHeight;
        if (!dom1 && !dom2) footerHeight = dom3.offsetHeight;
      }
      console.log(footerHeight);
      const bodyHeight = window.innerHeight;
      if (this.showFooter) {
        this.containerStyle = {
          height: `${window.innerHeight}px`,
        };
        this.contentStyle = {
          height: `${bodyHeight - statusBarHeight - headerHeight - footerHeight}px`,
          overflow: 'scroll',
          '-webkit-overflow-scrolling': 'touch',
        };
      } else {
        this.containerStyle = {
          height: `${window.innerHeight}px`,
        };
        this.contentStyle = {
          height: `${bodyHeight - statusBarHeight - headerHeight}px`,
          overflow: 'scroll',
          '-webkit-overflow-scrolling': 'touch',
        };
      }
    },
  },
};
</script>

<style lang="scss">
// $footerHeight: 56px;
.kde-container {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
}
.main-section {
  position: relative;
}
#footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 56px;
  background: #fff;
  box-sizing: content-box;
  // 适配iphonex
  @media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
    padding-bottom: 34px;
  }
  @media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {
    padding-bottom: 34px;
  }
  &.ftBorder {
    &::after {
      content: ' ';
      position: absolute;
      pointer-events: none;
      color: #eeeeee;
      border-top: 1px solid #eeeeee;
      height: 1px;
      left: 0;
      right: 0;
      top: 0;
    }
  }
}
#footers {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 0;
}
</style>
