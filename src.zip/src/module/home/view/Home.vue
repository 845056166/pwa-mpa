<template>
  <div class="overviewPage">
    <div class="full-page">
      <!-- 用户信息 -->
      <user-info
        :userInfo="userInfo"
        :mainProdName="mainProd.mainPlanShortName"
      ></user-info>
      <!-- 保险产品计划 -->
      <product-plan
        :mainProd="mainProd"
        :productPlanObj="productPlanObj"
        :health_360Flag="health_360Flag"
        :mainProductInfo="mainProductInfo"
        :millionInfo="millionInfo"
      ></product-plan>
      <!-- 产品亮点 -->
      <product-highlight
        :insuranceFeeItem="insuranceFeeItem"
        :mainPlanCode="mainProd.mainPlanCode"
      ></product-highlight>
      <!-- 保单利益 -->
      <product-benefit
        v-if="mainProd.mainPlanShortName"
        :benefitInfo="benefitInfo"
      ></product-benefit>
      <!-- 重要提示 -->
      <div v-if="importantPrompt && (importantPrompt.length > 0)" class="product-tips">
        <div class="product-tips-box">
          <h3 class="product-tips-title">
            <span class="title-name">重要提示</span>
          </h3>
          <div
            class="tips-data border-bottom"
          >{{importantPrompt[0].descContent || importantPrompt[0]}}</div>
          <div class="tips-show-more" @click="openInnerMask('tipsShow')">
            点击查看更多
            <i></i>
          </div>
        </div>
      </div>
      <!-- 就医360入口 -->
      <div class="medical360" @click="toHealthPage('all')" v-if="health_360Flag">
        <img src="../img/seekmedical360.png" alt />
        <div class="clickBox">
          <div class="medical360-btn" @click.stop="toHealthPage('diagnosis')"></div>
          <div class="medical360-btn" @click.stop="toHealthPage('cure')"></div>
          <div class="medical360-btn" @click.stop="toHealthPage('recovery')"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import numDeal from '@/assets/js/numDeal';
import userInfo from '@/components/insProposal/user-info';
import productPlan from '@/components/insProposal/product-plan';
import productHighlight from '@/components/insProposal/product-highlight';
import productBenefit from '@/components/insProposal/product-benefit';
import { getProposalInfo } from '../js/WXProposalInfo.js';
import info from '../js/proposalInfo.json';

export default {
  mixins: [numDeal],
  name: 'home',
  components: {
    userInfo,
    productPlan,
    productHighlight,
    productBenefit,
  },
  data() {
    return {
      userInfo: {}, // 用户信息
      mainProd: {}, // 主险信息
      productPlanObj: {}, // 保险产品计划模块所需要的信息大对象
      health_360Flag: false, // 360组合标志
      medical360: {}, // 就医360参数
      mainProductInfo: {}, // 主险基本保额/份数
      insuranceFeeItem: [], // 产品亮点模块所需要的信息
      disableCheckedSingle: [],
      benefitInfo: {}, // 保单利益模块所需要的信息
      importantPrompt: [], // 重要提示
      eShengBao2017Flag: false,
      eShengBaoFlag: false,
      mainPlanCode: '',
      millionInfo: null,
      feeObj: {}, // 多主险费用集合
    };
  },
  computed: {
    disableCheckedSingle3() {
      // 不展示保单年度和期交保险费
      const arr = this.disableCheckedSingle;
      console.log(arr, 'disableCheckedSingle3');
      const len = arr && arr.length;
      for (let i = 0; i < len; i++) {
        if (arr[i].E_Name === 'POL_YEAR' || arr[i].E_Name === 'PERIOD_INS_FEE') {
          arr[i].displayFlag = false;
        }
      }
      console.log(arr);
      return arr;
    },
    // shareSrc() {
    //   return require(`../img/short/${this.mainPlanCode}.jpg`);
    // },
  },
  created() {
    this.initOverviewData();
  },
  methods: {
    initOverviewData() {
      const url = 'https://stg.iobs.pingan.com.cn/download/pss-ics-core-dmz-dev/2059865ee3e04d81a6c158edd35651fb?t=1581137267952';
      getProposalInfo(url).then((res) => {
        const proposalInfo = res;
        // const proposalInfo = info;
        console.log(info, proposalInfo);
        this.getUserInfo(proposalInfo);
        this.mainProd = proposalInfo.mainProduct || {}; // 获取主险信息
        this.productPlanObj.productInfoList = proposalInfo.productInfoList; // 为了计算出首年保费或首月保费
        this.insuranceFeeItem = proposalInfo.insuranceFeeItem; // 产品亮点
        this.productPlanObj.planInfoList = this.getNewplanInfoList(proposalInfo.productInfoList, proposalInfo.addiPlanMapNew);
        this.disableCheckedSingle = proposalInfo.disableCheckedSingle; // disableCheckedSingle3所需
        this.hasHealth360(proposalInfo);
        this.getModuleInfo(proposalInfo);
        this.getMainProductInfo(proposalInfo.mainProduct.insuranceFeeDesc);
      }).catch((err) => {
        console.log('getProposalInfo catch');
        console.log(err);
      });
    },
    // 获取用户信息
    getUserInfo(res) {
      // console.log(res);
      const {
        isSameClient,
        appClientName,
        appClientSex,
        appClientAge,
        insClientName,
        insClientSex,
        insClientAge,
        isReserve,
        otherInsClientName,
        otherInsClientSex,
        otherInsClientAge,
      } = res;
      this.userInfo = {
        isSameClient,
        appClientName,
        appClientSex,
        appClientAge,
        insClientName,
        insClientSex,
        insClientAge,
        isReserve,
        otherInsClientName,
        otherInsClientSex,
        otherInsClientAge,
      };
    },
    /**
     * 当addiPlanInfoList.planCode等于addiPlanMapNew.planCodeForJ时，
     * 在当前addiPlanInfoList加对应的addiPlanMapNew中的list,组成新数组
     */
    getNewplanInfoList(list, item) {
      if (!item || !item.length) return list;
      const tempObj = Object.assign([], list);
      let t = 0; // 记录productInfoList.planCode等于addiPlanMapNew.planCodeForJ的次数
      for (let j = 0, len = list.length; j < len; j++) {
        for (let i = 0, len2 = item.length; i < len2; i++) {
          if (list[j].planCode === item[i].planCodeForJ) {
            if (list[j].groupOrder) item[i].groupOrder = list[j].groupOrder;
            t++; // 每等于一次，则+1
            if (t === 1) {
              // 第一次直接添加
              tempObj.splice(j, 0, item[i]);
            } else { // 否则，每添加一次原数组的长度都+1，j也需要+1
              tempObj.splice(j + t - 1, 0, item[i]);
            }
          }
        }
      }
      return Object.assign([], tempObj);
    },
    // 是否有360
    hasHealth360(res) {
      this.health_360Flag = res.hasHealthService_360 === 'Y';
      // 就医360参数赋值
      /* eslint-disable */
      const {
        totPremIum,
        totPremIum360,
        product_code_360,
        totPremIumDesc
      } = res;
      this.productPlanObj.medical360 = {
        totPremIum,
        totPremIum360,
        product_code_360,
        totPremIumDesc
      };
      /* eslint-enable */
    },
    // 获取各个模块需要的信息
    getModuleInfo(res) {
      const {
        eShengBaoGroup2017Flag,
        eShengBaoGroupFlag,
        mainPlanCode,
        lowRate,
        middleRate,
        highRate,
        disableCheckedSingle,
        disableCheckedLevels,
        benResultList,
        insClientAge,
        maxPolYear,
        addPlanCodeList,
        firstTableImportantPrompt,
        insIsMedicalInsured, // 有无社保
        propertyMillionAccompanying,
        propertyMillionPremIum,
      } = res;
      this.millionInfo = {
        propertyMillionAccompanying,
        propertyMillionPremIum,
      };
      this.mainPlanCode = mainPlanCode;
      this.benefitInfo = {
        // 保单利益模块所需要的信息
        lowRate,
        middleRate,
        highRate,
        disableCheckedSingle,
        disableCheckedLevels,
        disableCheckedSingle3: this.disableCheckedSingle3,
        benResultList,
        insClientAge,
        maxPolYear,
        mainProdPayperiod: this.mainProd.payPeriod,
        addPlanCodeList,
        mainProd: this.mainProd,
        insIsMedicalInsured,
      };
      this.tableObj = { // 利益演示表表长宽高等
        mainProdsWidth: window.innerWidth - parseInt(parseFloat(document.querySelector('html').style.fontSize, 10) * 0.6, 10),
        tableWidth: window.innerWidth - parseInt(parseFloat(document.querySelector('html').style.fontSize, 10) * 0.31, 10),
        tableHeight: parseInt(parseFloat(document.querySelector('html').style.fontSize, 10) * 8.4, 10),
        rowHeight: parseInt(parseFloat(document.querySelector('html').style.fontSize, 10) * 0.8, 10),
      };
      this.importantPrompt = firstTableImportantPrompt;
      const esbParam = {
        eShengBaoGroupFlag,
        eShengBaoGroup2017Flag,
        mainPlanCode,
      };
      this.hasEShengBao(esbParam);
    },
    // 获取主险基本保额/份数
    getMainProductInfo(item) {
      if (item.indexOf('份') !== -1) {
        this.mainProductInfo = {
          name: '份数(份)',
          value: parseFloat(item),
        };
        return;
      }
      if (item === '--') {
        this.mainProductInfo = {
          name: '基本保额(元)',
          value: '--',
        };
      } else {
        this.mainProductInfo = {
          name: '基本保额(元)',
          value: `${this.keepTwoDecimal(parseFloat(item) / 10000)}万`,
        };
      }
    },
    // 是否有e生保
    hasEShengBao(res) {
      const {
        eShengBaoGroupFlag,
        eShengBaoGroup2017Flag,
        mainPlanCode,
      } = res;
      if (eShengBaoGroup2017Flag === 'Y') this.eShengBao2017Flag = true;
      if (eShengBaoGroupFlag === 'Y' || mainPlanCode === '1020') this.eShengBaoFlag = true;
    },
  },
}
</script>


<style lang="scss">
@import "@/assets/css/common/mixin.scss";
// @import "../../../../node_modules/vue-easytable/libs/themes-base/index.css";
// @import "../css/overViewMain.scss";
.overviewPage {
  transform: translateZ(0);
}
.share_mask {
  position: absolute;
  width: 100%;
  background: rgba(0, 0, 0, 0.5);
  height: 100%;
}
.list-enter-active {
  animation: show ease 0.3s forwards;
}
.list-leave-active {
  animation: close ease 0.3s forwards;
}
@keyframes show {
  from {
    transform: translate3d(0, 100%, 0);
  }
  to {
    transform: translate3d(0, 0, 0);
  }
}
@keyframes close {
  from {
    transform: translate3d(0, 0, 0);
  }
  to {
    transform: translate3d(0, 100%, 0);
  }
}

.fade-enter-active {
  animation: fadeIn ease 0.3s forwards;
}
.fade-leave-active {
  animation: fadeOut ease 0.3s forwards;
}
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes fadeOut {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.matrix-container.vertify-circle {
  .matrix-loading-outer-neo {
    background-color: rgba(0, 0, 0, 0.5);
  }
}
.overviewPage .matrix-progress-bar {
  // top: -2px;
}
.overviewPage.main-prods-page {
  .user-wrap {
    margin-top: 12px;
    padding: 0 0.3rem;
    .user-card {
      padding: 0 0.06rem;
      .user-info .user-portrait {
        width: 48px;
        height: 48px;
      }
    }
  }
  .product-highlight-box .product-highlight-title {
    padding: 15px 0 5px;
  }
  .product {
    &-plan,
    &-highlight,
    &-benefit,
    &-tips {
      margin-top: 12px;
      padding: 0 0.3rem;
      &-title {
        padding: 15px 0;
        line-height: 27px;
        font-size: 19px;
        margin: 0;
        .title-name {
          padding: 0 28px;
          background-image: url("../img/l@3x.png"), url("../img/r@3x.png");
          background-size: 21px auto, 21px auto;
        }
      }
    }
  }
  .product-tips {
    margin-bottom: 12px;
  }
  .product-plan-box .plan-product-type  {
    // th, td {
    //   &::after{
    //     @include border(full, #E6E6E6);
    //   }
    // }
    tr {
      &:first-child {
        background: #f5f5f5;
      }
      &:not(:first-child) {
        background: #fff;
      }
    }
    td {
      font-family: PingFangSC-Regular;
      font-size: 13px;
      color: rgba(0, 0, 0, 0.85) !important;
    }
  }
  .product-plan-box .plan-product-type {
    margin: 0;
  }
  .product-highlight .product-highlight-notice {
    padding: 18px 0;
  }
  .product-highlight-box {
    padding: 0 0 18px;
  }
  .product-tips-box .tips-data {
    padding: 6px 0 9px;
  }
  .product-tips-box .tips-show-more {
    height: 54px;
    line-height: 54px;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.6);
  }
  .medical360 {
    margin-top: 12px;
    margin-bottom: 0px;
  }
  .matrix-btn__groups .matrix-btn__group .matrix__btn {
    border-radius: 40px;
  }
  .matrix__btn--primary {
    background-color: #ff7744;
  }
  .perfect-entrance {
    margin-top: 12px;
    margin-bottom: 12px;
  }
  .group-benefit-entrance {
    padding: 18px 0;
    margin-bottom: 12px;
    text-align: center;
    font-size: 13px;
    color: #5b91ff;
  }
  .benefit-box {
    position: absolute;
    bottom: 0;
    width: 100%;
    z-index: 102;
    background: #fff;
    // height: calc(50%+ 33px);
    // -webkit-overflow-scrolling: auto;
    .benefit-box_inner {
      height: calc(100% + 1px);
    }
    .icon-close {
      font-size: 15px;
      font-weight: 200;
      color: #ccc;
      float: right;
    }
    .benefit-title {
      // height: 33px;
      line-height: 25px;
      padding: 0px rem(36);
      font-size: 18px;
      text-align: center;
      font-family: PingFangSC-Semibold;
      color: rgba(0, 0, 0, 0.85);
      height: 56px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .benefit-title-name {
        flex: 1;
        height: 36px;
        line-height: 36px;
        margin: 0 0.18rem;
        &.active {
          border-bottom: 2px solid #ff721f;
        }
      }
      .close-btn {
        width: 15.5px;
        height: 15.5px;
        float: right;
        // margin-left: rem(20);
        margin: 16px 0 16px rem(20);
      }
    }
    .benefit-pop {
      width: 100%;
      position: relative;
      top: 0;
      left: 0.3rem;
    }
  }
  .v-table-header {
    td {
      font-size: 15px;
      color: rgba(0, 0, 0, 0.7);
      font-family: PingFangSC-Semibold;
    }
  }
  // .v-table-title-cell,
  // .v-table-body-cell,.v-table-header, .v-table-toolbar, .v-table-pager, .v-table-footer-inner {
  //   border-color: #ccc;
  // }
  .v-table-body-inner-pb {
    .v-table-body-cell {
      background: #f7f7f7;
    }
  }
  .v-table-views {
    box-sizing: border-box;
    position: relative;
    overflow: hidden;
    border: 1px solid #eee;
  }
  .v-table-body {
    -webkit-overflow-scrolling: auto;
  }
}

.overviewPage {
  background: #f7f7f7;
  .main-section {
    overflow-x: hidden !important;
  }
  &.noScroll {
    .main-section {
      overflow: hidden !important;
    }
  }
}
.overviewPage .product {
  &-plan,
  &-highlight,
  &-benefit,
  &-tips {
    margin-top: 9px;
    padding: 0 rem(36);
    background: #fff;
    &-title {
      text-align: center;
      padding: 13px 0;
      line-height: 28px;
      font-family: PingFangSC-Semibold;
      font-size: 20px;
      color: rgba(0, 0, 0, 0.85);
      .title-name {
        padding: 0 20px;
        background-image: url("../img/left-title.png"),
          url("../img/right-title.png");
        background-repeat: no-repeat;
        background-size: 13.5px auto, 13.5px auto;
        background-position: center left, center right;
      }
    }
  }
  &-highlight-box,
  &-benefit-box {
    padding: 0 0 rem(42);
  }
  &-plan {
    &-box {
      .plan-data {
        display: flex;
        flex-wrap: wrap;
        text-align: center;
        letter-spacing: 0;
        padding: 12px 0 17px;
        .plan-data-item {
          flex: 0 1 50%;
          // 适配iPad
          @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {
            flex: 0 1 25%;
          }
        }
        &.plan-medical360 {
          margin-bottom: 10px;
        }
        .first-fee {
          position: relative;
          .plan-notes {
            width: 100%;
            text-align: center;
            position: absolute;
            bottom: 0;
            line-height: 1.4;
            color: rgba(0, 0, 0, 0.6);
          }
        }
        .plan-value {
          line-height: 26.5px;
          font-size: 19px;
          font-family: PingFangSC-Semibold;
          color: #ff721f;
        }
        .plan-label {
          padding-bottom: 22px;
          padding-top: 15.5px;
          line-height: 21px;
          font-size: 15px;
          color: rgba(0, 0, 0, 0.45);
        }
      }
      .plan-product-type {
        margin: 0 0 30px 0;
        table {
          width: 100%;
          position: relative;
          border-collapse: collapse;
          font-family: PingFangSC-Semibold;
          font-size: 12px;
          color: rgba(0, 0, 0, 0.6);
          letter-spacing: 0;
          &::after {
            @include border(full, #eee);
          }
          .plan-table-first-fee .table-div {
            text-align: center;
          }
        }
        th,
        td {
          position: relative;
          margin: 0 auto;
          text-align: center;
          overflow: hidden;
          line-height: 16.5px;
          padding: 12.5px 0 11px;
          white-space: nowrap;
          &::after {
            @include border(full, #eee);
          }
          .table-div {
            width: auto;
            display: inline-block;
            // text-align: left;
            display: flex;
            justify-content: center;
            align-items: center;
          }
        }
        tr {
          &:nth-child(even) {
            background: #f7f7f7;
          }
        }
        td {
          &:not(:first-child) {
            font-family: PingFangSC-Regular;
          }
          &:nth-child(even) {
            color: #ff721f;
          }
        }
        th {
          box-sizing: border-box;
          font-size: 13px;
          color: rgba(0, 0, 0, 0.85);
          &:nth-child(1) {
            width: rem(186);
          }
          &:nth-child(2) {
            width: rem(127);
          }
          &:nth-child(3) {
            width: rem(189);
          }
          &:nth-child(4) {
            width: rem(175);
          }
        }
        &.carMillon {
          margin: 0;
          .plan-esb-list {
            text-align: center;
          }
          h3 {
            margin: 15px 0;
            text-align: center;
            font-size: 14px;
            position: relative;
            display: inline-block;
            color: rgba(0, 0, 0, 0.6);
            &::before {
              content: "";
              width: 1rem;
              border-bottom: 1px dashed rgba(0, 0, 0, 0.6);
              display: inline-block;
              position: absolute;
              top: 7px;
              left: -1.1rem;
            }
            &::after {
              content: "";
              width: 1rem;
              border-bottom: 1px dashed rgba(0, 0, 0, 0.6);
              display: inline-block;
              position: absolute;
              top: 7px;
              right: -1.1rem;
            }
          }
        }
      }
    }
  }
  &-highlight {
    &-title {
      margin-bottom: 21px;
    }
    .product-highlight-notice {
      padding: 21px 0.36rem;
      font-family: PingFangSC-Regular;
      font-size: 13px;
      line-height: 18px;
      color: rgba(0, 0, 0, 0.6);
    }
    &-box {
      .highlight-example {
        &-list {
          padding-left: rem(48);
          &-item {
            position: relative;
            padding-bottom: 21px;
            font-family: PingFangSC-Regular;
            &:not(:last-child) {
              margin-bottom: 21px;
            }
            h4 {
              display: flex;
              line-height: 24px;
              padding-bottom: 9px;
              margin-right: rem(149);
              font-family: PingFangSC-Semibold;
              font-size: 17px;
              color: rgba(0, 0, 0, 0.85);
              img {
                height: 18px;
                position: absolute;
                top: 3px;
                left: rem(-46);
              }
            }
            p:nth-of-type(1) {
              line-height: 22.5px;
              padding-bottom: 12px;
              font-size: 16px;
              color: rgba(0, 0, 0, 0.6);
            }
            p:nth-of-type(2) {
              line-height: 20px;
              font-size: 12px;
              color: rgba(0, 0, 0, 0.45);
            }
            // 安心百分百样式
            & > div.anxin {
              line-height: 20px;
              font-size: 12px;
              color: rgba(0, 0, 0, 0.6);
              p {
                line-height: 20px;
                font-size: 12px;
                color: rgba(0, 0, 0, 0.45);
                padding-bottom: 0;
              }
            }
            .detail-btn {
              position: absolute;
              top: 0;
              right: 0;
              display: flex;
              align-items: center;
              font-size: 13px;
              color: rgba(0, 0, 0, 0.45);
              line-height: 18px;
              i {
                display: inline-block;
                width: 12px;
                height: 24px;
                line-height: 18px;
                margin-left: rem(12);
                background-image: url("../img/more-icon.png");
                background-repeat: no-repeat;
                background-size: 100% 100%;
              }
            }
          }
        }
      }
      .highlight-bottom {
        display: flex;
        justify-content: center;
        font-size: 15px;
        font-family: PingFangSC-Regular;
        color: rgba(0, 0, 0, 0.85);
        .highlight-bottom-btn {
          width: rem(300);
          height: 40px;
          line-height: 40px;
          text-align: center;
          border: 1px solid #ccc;
          border-radius: rem(40);
        }
        &-insuredLiability {
          margin-right: rem(48);
        }
      }
    }
  }
  &-benefit {
    &-title {
      margin-bottom: 6px;
    }
    &-box {
      padding-bottom: 30px;
      .benefit-insurance-payment-list {
        &-item {
          position: relative;
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 15px 0;
          letter-spacing: 0;
          &:last-child {
            margin-bottom: 30px;
          }
          .label {
            font-family: PingFangSC-Regular;
            font-size: 16px;
            color: rgba(0, 0, 0, 0.6);
            line-height: 22.5px;
          }
          .value {
            font-family: PingFangSC-Semibold;
            font-size: 16px;
            color: rgba(0, 0, 0, 0.85);
          }
        }
        &-btn {
          display: flex;
          justify-content: flex-end;
          padding: 45px 0 15px;
          .benefit-btn {
            width: rem(140);
            height: 30px;
            margin-left: rem(20);
            border: 1px solid #ccc;
            line-height: 30px;
            text-align: center;
            font-family: PingFangSC-Medium;
            font-size: 14px;
            color: rgba(0, 0, 0, 0.7);
            border-radius: 2px;
            &.choosed {
              background: #ff721f;
              border-color: #ff721f;
              color: #fff;
            }
          }
        }
        .benefit-btn-content {
          font-size: 14px;
          text-align: right;
          color: #ff721f;
        }
      }
      .benefit-insurance-expenditure {
        padding: 0 rem(17);
        text-align: center;
        letter-spacing: 0;
        &.expenditure-fixed {
          position: fixed;
          bottom: -164px;
          width: calc(100% - 0.72rem);
          padding: 9px 0;
          background: #fff;
          z-index: 1;
        }
        p:nth-of-type(1) {
          line-height: 21px;
          font-family: PingFangSC-Semibold;
          font-size: 15px;
          color: rgba(0, 0, 0, 0.45);
        }
        .range {
          &-wrap {
            display: flex;
            padding: 32px 0 18px 0;
          }
          &-reduce,
          &-add {
            display: inline-block;
            width: 30px;
            height: 30px;
          }
          &-reduce {
            background-image: url("../img/-.png");
            background-repeat: no-repeat;
            background-size: 100% auto;
          }
          &-box {
            flex: 1;
            padding: 13px rem(12) 0;
          }
          &-add {
            background-image: url("../img/+.png");
            background-repeat: no-repeat;
            background-size: 100% auto;
            touch-action: none;
          }
        }
        p:nth-of-type(2) {
          line-height: 21px;
          font-family: PingFangSC-Regular;
          font-size: 15px;
          color: rgba(0, 0, 0, 0.85);
          height: 23px;
          i {
            font-family: Arial-BoldMT;
            font-size: 21px;
            line-height: 21px;
            color: #ff7217;
            span {
              font-family: PingFangSC-Semibold;
            }
          }
        }
      }
      .benefit-insurance-schedule {
        text-align: center;
        margin-top: 30px;
        span {
          border-radius: 0.4rem;
          color: rgba(0, 0, 0, 0.85);
          padding: 9.5px 0;
          display: inline-block;
          line-height: 21px;
          font-size: 15px;
          width: rem(300);
          border: 1px solid #ccc;
          font-family: PingFangSC-Regular;
        }
      }
    }
  }
  &-rights-content {
    > p {
      display: flex;
      padding: 10px 0.8rem;
      justify-content: space-between;
      span {
        font-size: 13px;
        text-decoration: underline;
        color: rgba(0, 0, 0, 0.6);
      }
    }
  }
  &-tips {
    &-box {
      .tips-data {
        line-height: 21px;
        padding: 21px 0;
        font-family: PingFangSC-Regular;
        font-size: 15px;
        color: rgba(0, 0, 0, 0.6);
      }
      .tips-show-more {
        // position: relative;
        // z-index: 1;
        display: flex;
        height: 50px;
        line-height: 50px;
        justify-content: center;
        align-items: center;
        font-size: 15px;
        color: rgba(0, 0, 0, 0.45);
        i {
          width: 12px;
          height: 24px;
          margin-left: rem(6);
          background-image: url("../img/more-icon.png");
          background-repeat: no-repeat;
          background-size: 100% auto;
        }
      }
    }
  }
}
.overviewPage .medical360 {
  padding: 15px 0.36rem;
  background: #fff;
  margin-top: 9px;
  margin-bottom: 9px;
  position: relative;
  img {
    width: 100%;
    border-radius: 5px;
    overflow: hidden;
    // border: 0.2rem solid rgb(255, 246, 231);
  }
  .clickBox {
    width: calc(100% - 45px);
    height: 105px;
    position: absolute;
    left: 0;
    bottom: 55px;
    margin: 0 0.45rem;
    display: flex;
    .medical360-btn {
      flex: 1;
    }
  }
}
.overviewPage .perfect-entrance {
  margin-top: 9px;
  margin-bottom: 9px;
  background: #fff;
  padding: 0 0.36rem;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  &.entrance-fixed {
    margin-top: 9px;
  }
  > span {
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: rgba(0, 0, 0, 0.85);
    line-height: 57px;
  }
  > img {
    display: block;
    width: 12px;
    height: 24px;
  }
}
.overviewPage .full-page {
  .redNum {
    font-family: PingFangSC-Semibold;
    color: #ff721f;
  }
  .blueLink {
    font-size: 14px;
    color: rgba(0, 0, 0, 0.85);
    text-decoration: underline;
    font-family: PingFangSC-Regular;
  }
  .vux-range-input-box {
    margin-right: 0 !important;
    margin-left: 0 !important;
  }
  .range-bar {
    background-image: linear-gradient(-90deg, #ffba4e 0%, #ff8426 100%);
    border-radius: 0.05rem;
  }

  .range-quantity {
    background-color: #ff8426;
    background-image: linear-gradient(-90deg, #ffba4e 0%, #ff8426 100%);
  }

  .range-handle {
    background: #ff8426;
    box-shadow: 0 0.05rem 0.1rem 0 rgba(255, 159, 58, 0.5);
    width: 25px;
    height: 25px;
    top: -10px !important;
  }

  .range-min,
  .range-max {
    display: none !important;
  }
}
.overviewPage .mask {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  background: rgba(0, 0, 0, 0.4);
}
.overviewPage .mask-box {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: rem(590);
  height: 369px;
  background-color: #ffffff;
}
.overviewPage .tips {
  &-mask {
    z-index: 20;
  }

  &-box {
    h2 {
      padding: 25px 0 15.5px;
      line-height: 21px;
      text-align: center;
      font-family: PingFangSC-Semibold;
      font-size: 18px;
      color: rgba(0, 0, 0, 0.85);
    }

    .tips-list {
      height: 262px;
      padding: 0 rem(36);
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
      scroll-behavior: smooth;

      &-item {
        line-height: 21px;
        padding-bottom: 5px;
        font-size: 15px;
        color: rgba(0, 0, 0, 0.85);
      }
    }

    .tips-close-btn {
      height: 45px;
      line-height: 45px;
      background: #ffffff;
      box-shadow: 0 -1px 0 0 #eeeeee;
      border-radius: 0 0 10px 10px;
      font-size: 15px;
      color: #ff721f;
      text-align: center;
    }
  }
}

.overviewPage .highlight-main .table-content-box {
  height: 200px;
  overflow: hidden;
  table {
    width: 200% !important;
    transform: scale(0.5) translate(-50%, -50%);
    tr {
      line-height: 40px;
    }
  }
}
.overviewPage .matrix-btn__group a:nth-of-type(2):hover {
  color: #fff;
}
.pub_outer {
  position: fixed;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
  z-index: 50;
  top: 0;
  left: 0;
  bottom: 0;
  text-align: center;
}
// 安心百分百样式
.anxin .pointDesc {
  font-size: 11px;
  color: #ff7217;
}
// 多主险样式
.main-prods-pop {
  width: 100%;
  background-color: #fff;
  position: absolute;
  bottom: 0;
  left: 0;
  z-index: 2;
  .pop-item {
    // height: 55px;
    line-height: 55px;
    font-size: 15px;
    text-align: left;
    padding: 0 0.36rem;
  }
  .item-con {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    &:active {
      background: #f7f7f7;
    }
    &::after {
      @include border(top, #eee);
    }
    .iconfont {
      color: #ff721f;
      font-size: 13px;
    }
  }
  .pop-title {
    font-size: 13px;
    color: #ff721f;
  }
  .pop-btn {
    border-top: 9px solid #f7f7f7;
    color: #ff721f;
    text-align: center;
  }
}
.proposalproOneYear {
  margin-left: 75px !important;
}
</style>
