import Ajax from '@/ajax.js';

export const getProposalInfo = url => new Promise((resolve) => {
  Ajax(url).then((res) => {
    resolve(res);
  }).catch((error) => {
    console.log(error);
  });
});