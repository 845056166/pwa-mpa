<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<style lang="scss">
@import '../../assets/css/common/common.scss';
#app {
  font-family: PingFangSC-Regular, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #333;
  height: 100%;
  width: 100%;
  -webkit-overflow-scrolling: touch;
}
body {
  line-height: 1.4;
}
html,
body {
  height: 100%;
  width: 100%;
  -webkit-overflow-scrolling: touch;
}
</style>

