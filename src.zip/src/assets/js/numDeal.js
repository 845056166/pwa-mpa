export default {
  methods: {
    // 保留最多两位小数
    keepTwoDecimal(num) {
      let result = parseFloat(num);
      if (window.isNaN(result)) {
        return false;
      }
      result = Math.round(num * 100) / 100;
      return result;
    },
    // 每三位加逗号
    toThousands(num = 0) {
      if (window.parseInt(num) < 1000) return num;
      let numS = num.toString();
      const y = numS.indexOf('.') + 1;
      let decimal = '';
      if (y > 0) {
        decimal = numS.slice(y);
      }
      numS = `${window.parseInt(numS, 10)}`;
      let result = '';
      while (numS.length > 3) {
        result = `,${numS.slice(-3)}${result}`;
        numS = numS.slice(0, numS.length - 3);
      }
      if (numS) { result = numS + result; }
      if (decimal) { result = `${result}.${decimal}`; }
      return result;
    },
    // 重置保费/份数
    setInsuranceFee(fee, caifu) {
      if (fee === '--' || fee.indexOf('份') > -1) {
        return fee;
      }
      if (!fee) {
        return '--';
      }
      if (caifu) {
        return `¥${parseFloat(fee)}`;
      }
      return `${this.keepTwoDecimal(parseFloat(fee) / 10000)}万`;
    },
  },
};
